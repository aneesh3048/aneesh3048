"""Init readers schema."""

# TODO: deprecate this file, only keep for backwards compatibility
from llama_index.readers.schema.base import Document, ImageDocument

__all__ = ["Document", "ImageDocument"]
