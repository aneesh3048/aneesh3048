# TODO: remove this file, only keep for backwards compatibility
from llama_index.schema import Document, ImageDocument  # noqa: F401
