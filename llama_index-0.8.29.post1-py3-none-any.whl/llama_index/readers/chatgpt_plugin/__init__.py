"""Init params."""

from llama_index.readers.chatgpt_plugin.base import ChatGPTRetrievalPluginReader

__all__ = ["ChatGPTRetrievalPluginReader"]
