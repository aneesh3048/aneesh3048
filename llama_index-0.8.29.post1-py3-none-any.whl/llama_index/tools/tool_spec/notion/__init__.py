"""Notion tool spec."""
